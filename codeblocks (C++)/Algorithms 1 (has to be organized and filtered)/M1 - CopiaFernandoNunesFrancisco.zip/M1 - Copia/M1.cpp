<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>
<CodeBlocks_project_file>
	<FileVersion major="1" minor="6" />
	<Project>
		<Option title="M1" />
		<Option pch_mode="2" />
		<Option compiler="gcc-msys2-mingw64" />
		<Build>
			<Target title="Debug">
				<Option output="bin/Debug/M1" prefix_auto="1" extension_auto="1" />
				<Option object_output="obj/Debug/" />
				<Option type="1" />
				<Option compiler="gcc-msys2-mingw64" />
			</Target>
			<Target title="Release">
				<Option output="bin/Release/M1" prefix_auto="1" extension_auto="1" />
				<Option object_output="obj/Release/" />
				<Option type="1" />
				<Option compiler="gcc-msys2-mingw64" />
			</Target>
		</Build>
		<Unit filename="main.cpp" />
		<Extensions>
			<lib_finder disable_auto="1" />
		</Extensions>
	</Project>
</CodeBlocks_project_file>
